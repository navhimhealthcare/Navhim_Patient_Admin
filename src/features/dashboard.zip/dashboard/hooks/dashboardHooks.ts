import { useState, useEffect, useCallback, useRef } from 'react'
import { dashboardService } from '../services/dashboardApi'
import showToast           from '../../../utils/toast'

export const useDashboard = () => {
  const [dashBoardCounts, setDashBoardCounts] = useState<any>([])
  const [loading,       setLoading]       = useState(true)
  const [actionLoading, setActionLoading] = useState(false)
  const isFetching = useRef(false)

  const fetchAll = useCallback(async () => {
    if (isFetching.current) return
    isFetching.current = true
    setLoading(true)
    try {
      const res = await dashboardService.getDashboardCounts()
      setDashBoardCounts(res.data.data)
    } catch (err: any) {
      showToast.error(err?.response?.data?.message || 'Failed to load categories.')
    } finally { 
      setLoading(false)
      isFetching.current = false
    }
  }, [])

  useEffect(() => { fetchAll() }, [fetchAll])

}