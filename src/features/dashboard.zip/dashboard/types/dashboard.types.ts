

export interface DashboardApiResponse {
  success: boolean
  status:  number
  message: string
  data:    {
    totalPatients: number
    totalAppointments: number
    totalRevenue: number
    totalDoctors: number
  }
}

export interface DashboardAppOverviewResponse {
  success: boolean
  status:  number
  message: string
  data:    {
    totalAppointments: number
    completedAppointments: number
    pendingAppointments: number
    cancelledAppointments: number
    upcomingAppointments: number
    missedAppointments: number
  }
}

export interface DashboardRecentResponse {
  success: boolean
  status:  number
  message: string
  data:    {
    appointments: {
      
    }
  }
}