import axiosInstance from '../../../services/axiosConfig'
import { DashboardApiResponse, DashboardAppOverviewResponse, DashboardRecentResponse } from '../types/dashboard.types'


export const dashboardService = {
  getDashboardCounts: () =>
    axiosInstance.get<DashboardApiResponse>('/dashboard/counts'),
  getDashboardAppOverview: (year: number) =>
    axiosInstance.get<DashboardAppOverviewResponse>(`dashboard/appointments/overview?year=${year}`),
  getDashboardAppRecent: () =>
    axiosInstance.get<DashboardRecentResponse>(`dashboard/appointments/recent`),
}