import { useEffect, useState } from "react";
import {
  SectionLoader,
  StatCardSkeleton,
} from "../../../components/Loader/Loader";
import { DepartmentLoad, TopDoctors } from "../components/DoctorWidgets";

import ActivityFeed from "../components/ActivityFeed";
import AppointmentChart from "../components/AppointmentChart";
import AppointmentsTable from "../components/AppointmentsTable";
import QuickActions from "../components/QuickActions";
import StatCard from "../components/StatCard";
import { STATS } from "../dashboardAPI";

export default function DashboardPage() {
  const [statsLoading, setStatsLoading] = useState(true);
  const [chartLoading, setChartLoading] = useState(true);

  // Simulate async data fetches
  useEffect(() => {
    const t1 = setTimeout(() => {
      setStatsLoading(false);
    }, 1400);
    const t2 = setTimeout(() => setChartLoading(false), 1800);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  return (
    <div className="flex flex-col gap-6">
      {/* ── Stat Cards ── */}
      <div className="grid grid-cols-4 gap-5">
        {statsLoading
          ? Array.from({ length: 4 }).map((_, i) => (
              <StatCardSkeleton key={i} />
            ))
          : STATS.map((stat, i) => (
              <div
                key={stat.id}
                style={{ animationDelay: `${i * 60}ms` }}
                className="animate-[fadeUp_0.4s_ease_both]"
              >
                <StatCard {...stat} />
              </div>
            ))}
      </div>

      {/* ── Chart + Activity ── */}
      <div className="grid grid-cols-[1fr_360px] gap-5">
        {chartLoading ? (
          <div className="bg-white rounded-2xl border border-brand-primary/[0.08]">
            <SectionLoader text="Loading chart…" />
          </div>
        ) : (
          <AppointmentChart />
        )}
          <TopDoctors />

        {/* <ActivityFeed /> */}
      </div>

      {/* ── Table + Side widgets ── */}
      <div className="grid grid-cols-[1fr_340px] gap-5">
        <AppointmentsTable />
        <div className="flex flex-col gap-5">
          <DepartmentLoad />
        </div>
      </div>

      {/* ── Quick Actions ── */}
      <QuickActions />
    </div>
    // <div>
    //   <h1>Dashboard Page</h1>
    // </div>
  );
}
